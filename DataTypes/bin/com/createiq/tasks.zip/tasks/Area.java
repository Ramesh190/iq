package com.createiq.tasks;

public class Area {
	public static void main(String args []) {
		int l=15;
		int b=23;
		double a=l*b;
		System.out.println(a);
	}

}
