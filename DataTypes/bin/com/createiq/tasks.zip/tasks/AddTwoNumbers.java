package com.createiq.tasks;

public class AddTwoNumbers {
	public static void main(String args []) {
		int x=35;
		int y=25;
		System.out.println("sum x + y ="+(x+y));
	}

}
