package com.createiq.tasks;

public class Short { 
	public static void main(String args []) {
		short heat=-25;
		System.out.println(heat);
	}

}
