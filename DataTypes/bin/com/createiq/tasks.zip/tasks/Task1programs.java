package com.createiq.tasks;

public class Task1programs {
	public static void main(String [] args ) {
		boolean flower=true;
		System.out.println(flower);
	}

}
