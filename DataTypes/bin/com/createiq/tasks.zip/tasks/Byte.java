package com.createiq.tasks;

public class Byte {
	public static void main(String args []) {
		byte range=60;
		System.out.println(range);
		
		
	}

}
