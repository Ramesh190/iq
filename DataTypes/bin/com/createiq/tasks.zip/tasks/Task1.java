package com.createiq.tasks;

public class Task1 {
	public static void main(String args []) {
     
		System.out.printf(" my name is  ramesh. i am 25 years old and i am from india.");
		
		System.out.println(" my favorite sport is vollyball.i play for one hour a day.");
	System.out.println("when i am tired.i like to play chess. i am in school,my favorite subject was telugu.i scored a 'A'.");
	}

}
