package com.createiq.tasks;

public class Double {
	public static void main(String args []) {
		double value=25.0256341332;
		System.out.println("double value ="+ value);
	}

}
