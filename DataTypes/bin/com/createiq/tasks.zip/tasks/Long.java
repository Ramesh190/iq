package com.createiq.tasks;

public class Long {
	public static void main(String args []) {
		long num=5442;
		System.out.println("num ="+ num);
	}

}
