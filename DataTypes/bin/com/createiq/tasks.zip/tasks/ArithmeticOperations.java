package com.createiq.tasks;

public class ArithmeticOperations {
	public static void main(String args []) {
		int num1=50;
		int num2=40;
		System.out.println("addition ="+(num1+num2));
		System.out.println("subtraction ="+(num1-num2));
		System.out.println("multiplication ="+(num1*num2));
		System.out.println("division ="+(num1/num2));
		System.out.println("modulo ="+(num1%num2));
	
	}

}
