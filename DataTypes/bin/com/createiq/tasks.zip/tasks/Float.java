package com.createiq.tasks;

public class Float {
	public static void main(String args []) {
		float value=15.25f;
		System.out.println(" float value ="+ value);
	}

}
