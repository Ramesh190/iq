package com.createiq.tasks;

public class Perimeter {
	public static void main(String args []) {
		int l=25;
		int b=10;
		double p=2*(l+b);
		System.out.println(p);
	}

}
