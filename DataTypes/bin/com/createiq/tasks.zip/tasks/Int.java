package com.createiq.tasks;

public class Int {
	public static void main(String args []) {
		int num=125;
		System.out.println(num);
	}

}
